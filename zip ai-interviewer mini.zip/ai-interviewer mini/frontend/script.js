document.getElementById("startInterview").addEventListener("click", () => {
    document.getElementById("questions").style.display = "block";
});

document.getElementById("finishInterview").addEventListener("click", async () => {

    const name = document.getElementById("name").value;
    const qualification = document.getElementById("qualification").value;
    const skills = document.getElementById("skills").value;
    const jobRole = document.getElementById("jobRole").value;

    const answers = {
        q1: document.getElementById("q1").value,
        q2: document.getElementById("q2").value,
        q3: document.getElementById("q3").value
    };

    const res = await fetch("http://127.0.0.1:5000/interview", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            name,
            qualification,
            skills,
            jobRole,
            answers
        })
    });

    const data = await res.json();

    // Applied Job Table
    let jobTable = `
    <h3>Applied Job Details</h3>
    <table class="fb-table">
        <tr><th>Candidate Name</th><td>${name}</td></tr>
        <tr><th>Qualification</th><td>${qualification}</td></tr>
        <tr><th>Skills</th><td>${skills}</td></tr>
        <tr><th>Job Role Applied</th><td>${jobRole}</td></tr>
    </table><br>`;


    // Feedback Table
    let table = `
    <h3>Interview Feedback</h3>
    <table class="fb-table">
        <tr><th>Technical Strengths</th><td>${data.technical_strengths}</td></tr>
        <tr><th>Weaknesses</th><td>${data.weaknesses}</td></tr>
        <tr><th>Communication</th><td>${data.communication}</td></tr>
        <tr><th>Recommendation</th><td>${data.recommendation}</td></tr>
        <tr><th>Final Decision</th><td>${data.decision}</td></tr>
    </table>
    `;

    document.getElementById("feedback").innerHTML = jobTable + table;
});
