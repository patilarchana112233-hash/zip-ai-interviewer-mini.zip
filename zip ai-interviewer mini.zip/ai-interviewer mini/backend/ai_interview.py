from flask import Flask, request, jsonify
from openai import OpenAI
from flask_cors import CORS

client = OpenAI()
app = Flask(__name__)
CORS(app)

@app.post("/interview")
def interview():
    data = request.json

    name = data.get("name")
    qualification = data.get("qualification")
    skills = data.get("skills")
    jobRole = data.get("jobRole")
    answers = data.get("answers")

    prompt = f"""
    Candidate Name: {name}
    Qualification: {qualification}
    Skills: {skills}
    Applied Job Role: {jobRole}

    Answers:
    Experience: {answers['q1']}
    Project: {answers['q2']}
    Challenges: {answers['q3']}

    Give output in 5 short bullet style responses:
    1. Technical Strengths
    2. Weaknesses
    3. Communication
    4. Recommendation
    5. Final Decision (Hire / Consider / Reject)
    """

    res = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}]
    )

    feedback = res.choices[0].message.content.split("\n")

    return jsonify({
        "technical_strengths": feedback[0],
        "weaknesses": feedback[1],
        "communication": feedback[2],
        "recommendation": feedback[3],
        "decision": feedback[4],
    })

if __name__ == "__main__":
    app.run(debug=True)
